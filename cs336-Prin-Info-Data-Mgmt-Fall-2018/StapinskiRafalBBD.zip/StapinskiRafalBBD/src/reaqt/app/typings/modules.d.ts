declare module "*.graphql" {
  export const kind: any;
  export const definitions: any;
}
