struct Node {
  int value;
  struct Node *next;
};
