# should set dynamic binds here but ¯\_(ツ)_/¯

import config.droplet as cf

db_user = cf.db_user
db_host = cf.db_host
db_name = cf.db_name
db_pass = cf.db_pass
